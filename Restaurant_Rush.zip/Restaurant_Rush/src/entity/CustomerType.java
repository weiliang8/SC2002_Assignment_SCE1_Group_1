package entity;

public enum CustomerType {
    REGULAR
} 
